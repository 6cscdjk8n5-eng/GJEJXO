-- Run this SQL in Supabase > SQL Editor.
create extension if not exists pgcrypto;

create table if not exists public.listings (
  id uuid primary key default gen_random_uuid(),
  title text not null check (char_length(title) between 4 and 100),
  description text not null check (char_length(description) between 10 and 1500),
  category text not null check (category in ('Produkte','Punë','Shërbime')),
  city text not null,
  price numeric(12,2) check (price is null or price >= 0),
  image_url text,
  contact text not null,
  status text not null default 'pending' check (status in ('pending','active','rejected','sold')),
  created_at timestamptz not null default now()
);

alter table public.listings enable row level security;

-- Visitors can read active listings only.
drop policy if exists "Anyone can read active listings" on public.listings;
create policy "Anyone can read active listings" on public.listings
for select using (status = 'active');

-- This starter deliberately does not allow unauthenticated writes directly through Supabase.
-- To enable safe public submissions, add Supabase Auth and server-side verification/rate limits.
-- The API route needs a secure authenticated user flow before it can insert pending rows.
