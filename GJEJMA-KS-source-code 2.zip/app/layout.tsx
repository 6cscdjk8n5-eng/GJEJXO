import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "GJEJMA KS — Gjej çka të duhet",
  description: "Marketplace për produkte, punë dhe shërbime në Kosovë, me ndihmës AI.",
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="sq"><body>{children}</body></html>;
}