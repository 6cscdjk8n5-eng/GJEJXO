import { NextRequest, NextResponse } from "next/server";

export async function POST(req: NextRequest) {
  const key = process.env.AI_API_KEY;
  if (!key) return NextResponse.json({ error: "AI nuk është lidhur ende. Shto AI_API_KEY në variablat e serverit." }, { status: 503 });
  let body: any;
  try { body = await req.json(); } catch { return NextResponse.json({ error: "Kërkesa nuk është valide." }, { status: 400 }); }
  const question = String(body.question ?? "").trim().slice(0, 1500);
  if (question.length < 2) return NextResponse.json({ error: "Shkruaj një pyetje." }, { status: 400 });
  const base = (process.env.AI_BASE_URL || "https://openrouter.ai/api/v1").replace(/\/+$/, "");
  const model = process.env.AI_MODEL || "openrouter/free";
  const listingContext = Array.isArray(body.listings) ? body.listings.slice(0,20).map((x:any) => ({
    title: String(x.title ?? "").slice(0,100), category: String(x.category ?? "").slice(0,30),
    city: String(x.city ?? "").slice(0,40), price: typeof x.price === "number" ? x.price : null
  })) : [];
  try {
    const response = await fetch(`${base}/chat/completions`, {
      method: "POST", headers: { "Authorization": `Bearer ${key}`, "Content-Type": "application/json", "HTTP-Referer": process.env.NEXT_PUBLIC_SITE_URL || "http://localhost:3000", "X-Title": "GJEJMA KS" },
      body: JSON.stringify({ model, messages: [
        { role: "system", content: "Je GJEJMA AI, ndihmës i marketplace-it GJEJMA KS në Kosovë. Përgjigju në shqip të qartë, miqësore dhe praktike. Ndihmo përdoruesin të përmirësojë kërkimin për produkte, punë dhe shërbime. Mos shpik se një shpallje ekziston; përdor vetëm kontekstin e dhënë dhe thuaj kur nuk ka përputhje. Kujtoju përdoruesve të verifikojnë shitësit dhe të mos dërgojnë para paraprakisht te persona të panjohur." },
        { role: "user", content: `Pyetja: ${question}\nShpallje aktuale (jo domosdoshmërisht të gjitha): ${JSON.stringify(listingContext)}` }
      ], temperature: 0.4, max_tokens: 500 })
    });
    const data = await response.json();
    if (!response.ok) return NextResponse.json({ error: "Ofruesi i AI nuk u përgjigj. Kontrollo çelësin, modelin dhe limitet e ofruesit." }, { status: 502 });
    const answer = data?.choices?.[0]?.message?.content;
    if (typeof answer !== "string" || !answer.trim()) return NextResponse.json({ error: "AI nuk ktheu përgjigje." }, { status: 502 });
    return NextResponse.json({ answer: answer.trim() });
  } catch {
    return NextResponse.json({ error: "Nuk u lidhëm me shërbimin AI. Provo përsëri." }, { status: 502 });
  }
}