import { NextRequest, NextResponse } from "next/server";
import { createClient } from "@supabase/supabase-js";

function db() {
  const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
  const key = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;
  if (!url || !key) return null;
  return createClient(url, key, { auth: { persistSession: false } });
}
const allowedCategories = new Set(["Produkte", "Punë", "Shërbime"]);
const allowedCities = new Set(["Mitrovicë","Prishtinë","Prizren","Pejë","Gjakovë","Gjilan","Ferizaj","Vushtrri","Podujevë","Fushë Kosovë","Tjetër"]);

export async function GET() {
  const supabase = db();
  if (!supabase) return NextResponse.json([]);
  const { data, error } = await supabase.from("listings").select("id,title,description,category,city,price,image_url,contact,created_at").eq("status","active").order("created_at",{ascending:false}).limit(100);
  if (error) return NextResponse.json({ error: "Nuk u lexuan shpalljet." }, { status: 500 });
  return NextResponse.json(data ?? []);
}

export async function POST(req: NextRequest) {
  const supabase = db();
  if (!supabase) return NextResponse.json({ error: "Databaza nuk është lidhur ende. Ndiq udhëzuesin README." }, { status: 503 });
  let body: any;
  try { body = await req.json(); } catch { return NextResponse.json({ error: "Të dhënat nuk janë valide." }, { status: 400 }); }
  const title = String(body.title ?? "").trim();
  const description = String(body.description ?? "").trim();
  const category = String(body.category ?? "");
  const city = String(body.city ?? "");
  const contact = String(body.contact ?? "").trim();
  const price = body.price === null || body.price === "" || body.price === undefined ? null : Number(body.price);
  if (title.length < 4 || title.length > 100 || description.length < 10 || description.length > 1500) return NextResponse.json({ error: "Kontrollo titullin dhe përshkrimin." }, { status: 400 });
  if (!allowedCategories.has(category) || !allowedCities.has(city)) return NextResponse.json({ error: "Kategoria ose qyteti nuk është valid." }, { status: 400 });
  if (contact.length < 3 || contact.length > 100 || (price !== null && (!Number.isFinite(price) || price < 0 || price > 10000000))) return NextResponse.json({ error: "Kontrollo kontaktin dhe çmimin." }, { status: 400 });
  // Public submissions are held for moderation. Do not expose a privileged service key in this route.
  const { data, error } = await supabase.from("listings").insert({ title, description, category, city, contact, price, status: "pending" }).select("id,title,description,category,city,price,image_url,contact,created_at").single();
  if (error) return NextResponse.json({ error: "Shpallja nuk u ruajt. Kontrollo politikat e databazës." }, { status: 500 });
  return NextResponse.json({ ...data, moderation: "pending" }, { status: 201 });
}