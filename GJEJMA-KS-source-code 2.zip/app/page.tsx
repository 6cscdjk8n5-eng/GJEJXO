 "use client";

import { useEffect, useMemo, useState } from "react";
import { Search, MapPin, Plus, Sparkles, ShoppingBag, BriefcaseBusiness, Wrench, Menu, X, ArrowRight, ShieldCheck, MessageCircle, SlidersHorizontal } from "lucide-react";

type Listing = { id: string; title: string; description: string; category: string; city: string; price: number | null; image_url: string | null; contact: string | null; created_at?: string; };
const categories = [
  { name: "Produkte", icon: ShoppingBag, description: "Telefona, pajisje, shtëpi e më shumë" },
  { name: "Punë", icon: BriefcaseBusiness, description: "Mundësi pune në qytetin tënd" },
  { name: "Shërbime", icon: Wrench, description: "Profesionistë dhe biznese lokale" },
];
const sample: Listing[] = [
  { id: "demo1", title: "iPhone 13 — gjendje shumë e mirë", description: "Telefon i përdorur me kujdes, funksionon mirë.", category: "Produkte", city: "Mitrovicë", price: 260, image_url: null, contact: null },
  { id: "demo2", title: "Kërkohet kamarier/e", description: "Restorant lokal kërkon punëtor/e me orar të plotë.", category: "Punë", city: "Prishtinë", price: null, image_url: null, contact: null },
  { id: "demo3", title: "Riparim i telefonave", description: "Diagnostikim dhe riparim i pajisjeve mobile.", category: "Shërbime", city: "Mitrovicë", price: null, image_url: null, contact: null },
  { id: "demo4", title: "Tavolinë pune për shtëpi", description: "Tavolinë e pastër, e përshtatshme për studim ose zyrë.", category: "Produkte", city: "Vushtrri", price: 45, image_url: null, contact: null },
];

export default function Home() {
  const [listings, setListings] = useState<Listing[]>(sample);
  const [query, setQuery] = useState("");
  const [category, setCategory] = useState("Të gjitha");
  const [city, setCity] = useState("Të gjitha qytetet");
  const [loading, setLoading] = useState(true);
  const [showPost, setShowPost] = useState(false);
  const [showAI, setShowAI] = useState(false);
  const [mobileMenu, setMobileMenu] = useState(false);
  const [aiQuestion, setAiQuestion] = useState("");
  const [aiAnswer, setAiAnswer] = useState("");
  const [aiLoading, setAiLoading] = useState(false);
  const [form, setForm] = useState({ title: "", description: "", category: "Produkte", city: "Mitrovicë", price: "", contact: "" });
  const [notice, setNotice] = useState("");

  useEffect(() => {
    fetch("/api/listings").then(r => r.ok ? r.json() : Promise.reject()).then(data => {
      if (Array.isArray(data) && data.length) setListings(data);
    }).catch(() => {}).finally(() => setLoading(false));
  }, []);

  const filtered = useMemo(() => listings.filter(item => {
    const text = `${item.title} ${item.description} ${item.city} ${item.category}`.toLowerCase();
    return (category === "Të gjitha" || item.category === category) &&
      (city === "Të gjitha qytetet" || item.city === city) &&
      (!query.trim() || text.includes(query.toLowerCase().trim()));
  }), [listings, query, category, city]);

  async function submitListing(e: React.FormEvent) {
    e.preventDefault(); setNotice("");
    const payload = { ...form, price: form.price ? Number(form.price) : null };
    try {
      const res = await fetch("/api/listings", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(payload) });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Nuk u publikua shpallja.");
      setListings(prev => [data, ...prev.filter(x => !x.id.startsWith("demo"))]);
      setShowPost(false); setForm({ title: "", description: "", category: "Produkte", city: "Mitrovicë", price: "", contact: "" });
      setNotice("Shpallja u publikua me sukses.");
    } catch (err) { setNotice(err instanceof Error ? err.message : "Gabim. Kontrollo konfigurimin e databazës."); }
  }

  async function askAI(e: React.FormEvent) {
    e.preventDefault(); if (!aiQuestion.trim()) return;
    setAiLoading(true); setAiAnswer("");
    try {
      const res = await fetch("/api/ai", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ question: aiQuestion, listings: listings.slice(0, 20).map(x => ({ title: x.title, category: x.category, city: x.city, price: x.price })) }) });
      const data = await res.json(); if (!res.ok) throw new Error(data.error || "AI nuk është konfiguruar.");
      setAiAnswer(data.answer);
    } catch (err) { setAiAnswer(err instanceof Error ? err.message : "Ndodhi një gabim."); }
    finally { setAiLoading(false); }
  }

  return <main>
    <header className="nav">
      <a className="brand" href="#"><span className="brandMark">G</span><span>GJEJMA<span className="brandKs"> KS</span><small>Gjej çka të duhet.</small></span></a>
      <nav className={mobileMenu ? "navLinks open" : "navLinks"}>
        <a href="#shpalljet" onClick={() => setMobileMenu(false)}>Shpalljet</a><a href="#kategorite" onClick={() => setMobileMenu(false)}>Kategoritë</a>
        <button className="navAI" onClick={() => {setShowAI(true);setMobileMenu(false)}}><Sparkles size={16}/> Pyete AI</button>
        <button className="primary small" onClick={() => {setShowPost(true);setMobileMenu(false)}}><Plus size={16}/> Publiko shpallje</button>
      </nav>
      <button className="menuBtn" onClick={() => setMobileMenu(!mobileMenu)} aria-label="Hap menynë">{mobileMenu ? <X/> : <Menu/>}</button>
    </header>

    <section className="hero">
      <div className="heroGlow"></div><div className="heroContent">
        <div className="eyebrow"><span className="liveDot"></span> Marketplace për krejt Kosovën</div>
        <h1>Çka po kërkon?<br/><span>Gjeje këtu.</span></h1>
        <p>Produkte, punë dhe shërbime nga njerëzit e bizneset afër teje. Krejt në një vend.</p>
        <div className="searchBox"><Search size={21}/><input value={query} onChange={e => setQuery(e.target.value)} placeholder="Kërko telefon, punë, mekanik..." aria-label="Kërko shpallje"/><button onClick={() => document.getElementById("shpalljet")?.scrollIntoView({behavior:"smooth"})}>Kërko <ArrowRight size={16}/></button></div>
        <div className="popular"><span>Të kërkuara:</span>{["iPhone","Punë","Vetura","Riparime"].map(t=><button key={t} onClick={()=>setQuery(t)}>{t}</button>)}</div>
      </div>
      <div className="heroAside"><div className="orbit orbitOne"></div><div className="orbit orbitTwo"></div><div className="heroCard"><div className="heroCardTop"><span className="miniIcon"><Sparkles size={18}/></span><span className="statusPill">AI i gatshëm</span></div><p className="muted">Gjej më shpejt me</p><h3>GJEJMA AI</h3><p>Shkruaje çka të duhet. AI të ndihmon të gjesh kategori, fjalë kyçe dhe shpallje relevante.</p><button className="aiCardBtn" onClick={()=>setShowAI(true)}>Provoje AI <ArrowRight size={16}/></button><div className="cardDecor">✳</div></div></div>
    </section>

    <section className="trustStrip"><div><ShieldCheck size={19}/><span>Shpallje të organizuara</span></div><div><MapPin size={19}/><span>Kërko sipas qytetit</span></div><div><MessageCircle size={19}/><span>Kontakto publikuesin</span></div></section>

    <section className="section" id="kategorite"><div className="sectionHead"><div><span className="kicker">GJEJ ÇKA TË DUHET</span><h2>Një vend. Shumë mundësi.</h2></div><p>Zgjedhe kategorinë dhe fillo kërkimin.</p></div>
      <div className="categoryGrid">{categories.map(c=>{const Icon=c.icon;return <button className={"categoryCard "+(category===c.name?"selected":"")} key={c.name} onClick={()=>{setCategory(category===c.name?"Të gjitha":c.name);document.getElementById("shpalljet")?.scrollIntoView({behavior:"smooth"})}}><span className="categoryIcon"><Icon size={23}/></span><span className="categoryText"><b>{c.name}</b><small>{c.description}</small></span><ArrowRight className="categoryArrow" size={18}/></button>})}</div>
    </section>

    <section className="section listingsSection" id="shpalljet"><div className="sectionHead"><div><span className="kicker">TË FUNDIT</span><h2>Shpalljet që mund të të duhen</h2></div><button className="outlineBtn" onClick={()=>setShowPost(true)}><Plus size={16}/> Publiko shpallje</button></div>
      <div className="filters"><div className="filterSearch"><Search size={17}/><input value={query} onChange={e=>setQuery(e.target.value)} placeholder="Kërko në shpallje..."/></div><label className="selectWrap"><SlidersHorizontal size={16}/><select value={category} onChange={e=>setCategory(e.target.value)}><option>Të gjitha</option><option>Produkte</option><option>Punë</option><option>Shërbime</option></select></label><label className="selectWrap"><MapPin size={16}/><select value={city} onChange={e=>setCity(e.target.value)}><option>Të gjitha qytetet</option>{["Mitrovicë","Prishtinë","Prizren","Pejë","Gjakovë","Gjilan","Ferizaj","Vushtrri","Podujevë","Fushë Kosovë"].map(x=><option key={x}>{x}</option>)}</select></label></div>
      {notice && <div className="notice">{notice}</div>}
      {loading && <p className="muted">Duke i ngarkuar shpalljet…</p>}
      <div className="listingGrid">{filtered.map((item,i)=><article className="listingCard" key={item.id}><div className={"listingVisual visual"+(i%4)}><span className="listingTag">{item.category}</span><span className="visualIcon">{item.category==="Produkte"?"◈":item.category==="Punë"?"↗":"✳"}</span><span className="visualCity"><MapPin size={13}/>{item.city}</span></div><div className="listingInfo"><h3>{item.title}</h3><p>{item.description}</p><div className="listingBottom"><b>{item.price != null ? `${item.price.toLocaleString("sq-AL")} €` : item.category==="Punë" ? "Mundësi pune" : "Kontakto për çmim"}</b><button aria-label={"Detaje për "+item.title} onClick={()=>alert(`${item.title}\n\n${item.description}\nQyteti: ${item.city}\n${item.price != null ? "Çmimi: "+item.price+" €\n" : ""}${item.contact ? "Kontakti: "+item.contact : "Kontakti publikohet nga shitësi"}`)}>Shiko <ArrowRight size={15}/></button></div></div></article>)}</div>
      {!filtered.length && <div className="empty"><Search size={28}/><h3>Nuk u gjetën shpallje</h3><p>Provo një kërkim tjetër ose publiko shpalljen e parë.</p><button className="primary" onClick={()=>setShowPost(true)}><Plus size={16}/> Publiko shpallje</button></div>}
      <div className="listingFoot">{filtered.length} shpallje në pamje <span>Shembujt demonstrues zëvendësohen kur databaza lidhet.</span></div>
    </section>

    <section className="aiBanner"><div className="aiBannerIcon"><Sparkles size={28}/></div><div><span className="kicker">GJEJMA AI</span><h2>Nuk e di ku me kërku?</h2><p>Trego çka të duhet dhe merr sugjerime për kërkim më të saktë.</p></div><button className="lightBtn" onClick={()=>setShowAI(true)}>Pyete GJEJMA AI <ArrowRight size={16}/></button></section>
    <footer><a className="brand footerBrand" href="#"><span className="brandMark">G</span><span>GJEJMA<span className="brandKs"> KS</span><small>Gjej çka të duhet.</small></span></a><p>Marketplace lokal për Kosovë.</p><span>© {new Date().getFullYear()} GJEJMA KS</span></footer>

    {showPost && <div className="modalBackdrop" onClick={()=>setShowPost(false)}><section className="modal" onClick={e=>e.stopPropagation()}><button className="modalClose" onClick={()=>setShowPost(false)}><X/></button><span className="kicker">KONTRIBUO NË GJEJMA KS</span><h2>Publiko shpallje</h2><p className="muted">Plotëso të dhënat. Me databazë të lidhur, shpallja ruhet online.</p><form onSubmit={submitListing} className="modalForm"><label>Titulli<input required minLength={4} maxLength={100} value={form.title} onChange={e=>setForm({...form,title:e.target.value})} placeholder="p.sh. Shitet iPhone 13"/></label><label>Kategoria<select value={form.category} onChange={e=>setForm({...form,category:e.target.value})}><option>Produkte</option><option>Punë</option><option>Shërbime</option></select></label><label>Qyteti<select value={form.city} onChange={e=>setForm({...form,city:e.target.value})}>{["Mitrovicë","Prishtinë","Prizren","Pejë","Gjakovë","Gjilan","Ferizaj","Vushtrri","Podujevë","Fushë Kosovë","Tjetër"].map(x=><option key={x}>{x}</option>)}</select></label><label>Çmimi (€) — lëre bosh nëse s'ka çmim<input type="number" min="0" max="10000000" value={form.price} onChange={e=>setForm({...form,price:e.target.value})} placeholder="p.sh. 120"/></label><label>Përshkrimi<textarea required minLength={10} maxLength={1500} value={form.description} onChange={e=>setForm({...form,description:e.target.value})} placeholder="Jep detajet kryesore..."/></label><label>Kontakt (telefon ose email)<input required maxLength={100} value={form.contact} onChange={e=>setForm({...form,contact:e.target.value})} placeholder="Si mund të të kontaktojnë?"/></label><button className="primary full" type="submit">Publiko shpalljen <ArrowRight size={16}/></button></form></section></div>}

    {showAI && <div className="modalBackdrop" onClick={()=>setShowAI(false)}><section className="modal aiModal" onClick={e=>e.stopPropagation()}><button className="modalClose" onClick={()=>setShowAI(false)}><X/></button><span className="kicker"><Sparkles size={14}/> GJEJMA AI</span><h2>Çka po kërkon sot?</h2><p className="muted">AI mund të të ndihmojë me ide kërkimi dhe të përdorë listën aktuale të shpalljeve si kontekst.</p><form onSubmit={askAI} className="aiAsk"><textarea value={aiQuestion} onChange={e=>setAiQuestion(e.target.value)} placeholder="p.sh. Po kërkoj telefon deri 200€ në Mitrovicë..." required maxLength={1500}/><button className="primary" disabled={aiLoading}>{aiLoading?"Duke menduar…":<><Sparkles size={16}/> Pyete AI</>}</button></form>{aiAnswer && <div className="aiAnswer"><b><Sparkles size={15}/> Përgjigjja</b><p>{aiAnswer}</p></div>}<p className="tinyNote">Përgjigjet e AI mund të jenë të pasakta. Kontrollo çmimet dhe detajet me publikuesin.</p></section></div>}
  </main>;
}