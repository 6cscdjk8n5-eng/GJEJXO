# GJEJMA KS — Marketplace + AI

Starter full-stack app for a Kosovo marketplace for products, jobs, and services. Built with Next.js and Supabase, with an OpenAI-compatible AI endpoint (default configured for OpenRouter).

## What is included

- Responsive Albanian-language marketplace interface.
- Search, category filters, and city filters.
- Listing submission form with validation.
- AI assistant endpoint (`/api/ai`) with server-side API key handling.
- Supabase schema with moderation statuses (`pending`, `active`, `rejected`, `sold`).
- Demo listings so the front page is visible before setup.

## Important: setup is required before real public launch

This is a working starter project, not a deployed service. You need to create/connect your own database and AI provider account. Free AI models may have rate limits, change availability, or stop being free. Hosting and database providers may also have usage limits.

## 1. Requirements

Install Node.js 20+ and npm on a computer, or use a cloud development environment that supports Next.js. A phone alone can manage some provider dashboards, but coding/build/deployment is much easier in a computer or cloud IDE.

## 2. Run locally

```bash
npm install
cp .env.example .env.local
npm run dev
```

Open `http://localhost:3000`.

## 3. Configure Supabase

1. Create a project at https://supabase.com/.
2. Open SQL Editor and run `supabase/schema.sql`.
3. Copy Project URL and anon/public key from Supabase project API settings into `.env.local`.
4. Public listing submissions are intentionally not enabled in the database policy yet. Before launch, implement authentication and server-side validation/rate limiting, or a secure server-side moderation queue. Do not paste a Supabase service-role key into client-side code.

The listing form will return a clear configuration error until secure insert permissions are configured.

## 4. Configure AI

1. Create a provider API key, for example at https://openrouter.ai/keys.
2. Add the following to `.env.local`:

```env
AI_API_KEY=your_secret_key
AI_BASE_URL=https://openrouter.ai/api/v1
AI_MODEL=openrouter/free
```

The `openrouter/free` router can choose among available free models, but it may be rate-limited and is not guaranteed to be available forever. For another OpenAI-compatible provider, change `AI_BASE_URL` and `AI_MODEL`. Keep `AI_API_KEY` server-side; never prefix it with `NEXT_PUBLIC_`.

## 5. Deploy

You can deploy the Next.js app on https://vercel.com/ or another host that supports Next.js.

1. Push this folder to a private GitHub repository.
2. Import it into your hosting provider.
3. Add the environment variables from `.env.example` in the hosting dashboard.
4. Deploy and test `/api/ai` and `/api/listings`.

## Before opening to the public

This starter is not yet production-ready for a public classifieds site. Add:
- Supabase Auth, account profiles, ownership checks, edit/delete listing flows.
- Authenticated and rate-limited listing creation; moderation/admin dashboard.
- Image uploads using Supabase Storage with file type/size checks.
- CAPTCHA or anti-spam protections and abuse reporting.
- Privacy policy, terms, contact details, and a process for illegal/scam listings.
- Payment provider integration only after confirming local availability and legal/tax requirements.
- Monitoring, backups, and moderation procedures.

Never store admin passwords or secret API keys in frontend code. Do not claim that listings are verified unless a real verification process exists.
